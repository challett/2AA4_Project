﻿Public Class Form3

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GameResume_Click(sender As Object, e As EventArgs) Handles GameResume.Click
        Me.Hide()
        Form1.Show()

        'PAUSE TIMER

    End Sub

End Class